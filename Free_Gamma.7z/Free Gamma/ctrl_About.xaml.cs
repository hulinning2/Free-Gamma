﻿
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Free_Gamma
{
    public partial class ctrl_About: UserControl
    {
        
        public ctrl_About() {
            InitializeComponent();
        }



    }
}